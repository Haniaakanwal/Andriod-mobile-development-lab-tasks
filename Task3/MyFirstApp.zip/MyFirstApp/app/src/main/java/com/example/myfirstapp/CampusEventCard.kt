package com.example.myfirstapp

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myfirstapp.ui.theme.MyFirstAppTheme

@Composable
fun CampusEventCard(
    title: String,
    date: String,
    venue: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.event_workshop),
                contentDescription = "Students attending the Android workshop",
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(text = title, style = MaterialTheme.typography.titleMedium)
                Text(text = date, style = MaterialTheme.typography.bodyMedium)
                Text(text = venue, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Preview(name = "Normal 360dp", widthDp = 360, showBackground = true)
@Composable
fun CampusEventCardNormalPreview() {
    MyFirstAppTheme {
        CampusEventCard(
            title = "Android Workshop",
            date = "12 November 2026",
            venue = "Software Engineering Lab"
        )
    }
}

@Preview(name = "Narrow 280dp", widthDp = 280, showBackground = true)
@Composable
fun CampusEventCardNarrowPreview() {
    MyFirstAppTheme {
        CampusEventCard(
            title = "Inter-University Software Engineering Innovation Workshop",
            date = "12 November 2026",
            venue = "Main Auditorium, Block B, University of Azad Jammu and Kashmir"
        )
    }
}

@Preview(
    name = "Dark 360dp",
    widthDp = 360,
    showBackground = true,
    uiMode = Configuration.UI_MODE_NIGHT_YES
)
@Composable
fun CampusEventCardDarkPreview() {
    MyFirstAppTheme(darkTheme = true) {
        CampusEventCard(
            title = "Android Workshop",
            date = "12 November 2026",
            venue = "Software Engineering Lab"
        )
    }
}

