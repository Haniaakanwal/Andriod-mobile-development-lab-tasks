package com.example.myfirstapp

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.myfirstapp.ui.theme.MyFirstAppTheme

@Composable
fun EventSummary(
    title: String,
    venue: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(text = title, style = MaterialTheme.typography.titleMedium)
        Text(text = venue, style = MaterialTheme.typography.bodyMedium)
    }
}

@Preview(showBackground = true)
@Composable
fun EventSummaryWorkshopPreview() {
    MyFirstAppTheme {
        EventSummary(
            title = "Android Workshop",
            venue = "Software Engineering Lab"
        )
    }
}

@Preview(showBackground = true)
@Composable
fun EventSummaryBookFairPreview() {
    MyFirstAppTheme {
        EventSummary(
            title = "Annual Book Fair",
            venue = "Main Library Hall"
        )
    }
}
