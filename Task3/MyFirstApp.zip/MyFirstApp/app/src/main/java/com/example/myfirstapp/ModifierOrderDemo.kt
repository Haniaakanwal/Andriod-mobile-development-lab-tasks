package com.example.myfirstapp

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Preview(showBackground = true, widthDp = 360)
@Composable
fun ModifierOrderComparisonPreview() {
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Text(
            text = "background, then padding",
            modifier = Modifier
                .background(Color.LightGray)
                .padding(16.dp)
        )
        Text(
            text = "padding, then background",
            modifier = Modifier
                .padding(16.dp)
                .background(Color.LightGray)
        )
    }
}
