package com.example.myfirstapp

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll

import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myfirstapp.ui.theme.MyFirstAppTheme
import kotlin.math.roundToInt

private val programmes = listOf(
    "Software Engineering ",
    "Computer Science",
    "Information Technology"
)
private val studyModes = listOf("On campus", "Online")

@Composable
fun RegistrationFormScreen(modifier: Modifier = Modifier) {
    // Individual observable state variables (initial values as required)
    var fullName by remember { mutableStateOf("") }
    var rollNumber by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var programme by remember { mutableStateOf("") }
    var programmeExpanded by remember { mutableStateOf(false) }
    var studyMode by remember { mutableStateOf("") }
    var mobileDev by remember { mutableStateOf(false) }
    var webDev by remember { mutableStateOf(false) }
    var softwareTesting by remember { mutableStateOf(false) }
    var courseUpdates by remember { mutableStateOf(false) }
    var studyHours by remember { mutableFloatStateOf(0f) }
    var submitAttempted by remember { mutableStateOf(false) }
    var showSuccess by remember { mutableStateOf(false) }

    // Validation results (messages are shown only after Register was pressed)
    val nameError = submitAttempted && fullName.trim().isEmpty()
    val rollError = submitAttempted && rollNumber.trim().isEmpty()
    val emailError = submitAttempted && email.trim().isEmpty()
    val programmeError = submitAttempted && programme.isEmpty()
    val modeError = submitAttempted && studyMode.isEmpty()

    Column(
        modifier = modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Student Registration",
            style = MaterialTheme.typography.headlineSmall
        )

        OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it; showSuccess = false },
            label = { Text("Full name") },
            singleLine = true,
            isError = nameError,
            supportingText = { if (nameError) Text("Full name is required") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = rollNumber,
            onValueChange = { rollNumber = it; showSuccess = false },
            label = { Text("Roll number") },
            singleLine = true,
            isError = rollError,
            supportingText = { if (rollError) Text("Roll number is required") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = email,
            onValueChange = { email = it; showSuccess = false },
            label = { Text("Email") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            isError = emailError,
            supportingText = { if (emailError) Text("Email is required") },
            modifier = Modifier.fillMaxWidth()
        )

        // Programme dropdown
        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = if (programme.isEmpty()) "Select programme" else programme,
                onValueChange = {},
                readOnly = true,
                label = { Text("Programme") },
                trailingIcon = { Text("\u25BE") },
                isError = programmeError,
                supportingText = { if (programmeError) Text("Please select a programme") },
                modifier = Modifier.fillMaxWidth()
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clickable { programmeExpanded = true }
            )
            DropdownMenu(
                expanded = programmeExpanded,
                onDismissRequest = { programmeExpanded = false }
            ) {
                programmes.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            programme = option
                            programmeExpanded = false
                            showSuccess = false
                        }
                    )
                }
            }
        }

        // Study mode radio group (only one can be selected)
        Text(text = "Study mode", style = MaterialTheme.typography.titleSmall)
        Column(modifier = Modifier.selectableGroup()) {
            studyModes.forEach { mode ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .selectable(
                            selected = studyMode == mode,
                            onClick = { studyMode = mode; showSuccess = false },
                            role = Role.RadioButton
                        )
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = studyMode == mode, onClick = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(mode)
                }
            }
        }
        if (modeError) {
            Text(
                text = "Please select a study mode",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }

        // Independent interest checkboxes
        Text(text = "Interests", style = MaterialTheme.typography.titleSmall)
        LabeledCheckbox("Mobile Development", mobileDev) { mobileDev = it; showSuccess = false }
        LabeledCheckbox("Web Development", webDev) { webDev = it; showSuccess = false }
        LabeledCheckbox("Software Testing", softwareTesting) { softwareTesting = it; showSuccess = false }

        // Course updates switch
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Receive course updates")
            Switch(
                checked = courseUpdates,
                onCheckedChange = { courseUpdates = it; showSuccess = false }
            )
        }

        // Weekly study hours slider (whole hours, 0 to 20)
        Text(text = "Weekly study hours: ${studyHours.roundToInt()}")
        Slider(
            value = studyHours,
            onValueChange = { studyHours = it; showSuccess = false },
            valueRange = 0f..20f,
            steps = 19
        )

        // Register and Reset buttons
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                submitAttempted = true
                showSuccess = fullName.trim().isNotEmpty() &&
                        rollNumber.trim().isNotEmpty() &&
                        email.trim().isNotEmpty() &&
                        programme.isNotEmpty() &&
                        studyMode.isNotEmpty()
            }) {
                Text("Register")
            }
            OutlinedButton(onClick = {
                fullName = ""
                rollNumber = ""
                email = ""
                programme = ""
                programmeExpanded = false
                studyMode = ""
                mobileDev = false
                webDev = false
                softwareTesting = false
                courseUpdates = false
                studyHours = 0f
                submitAttempted = false
                showSuccess = false
            }) {
                Text("Reset")
            }
        }

        if (showSuccess) {
            Text(
                text = "Registration form completed successfully",
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Composable
private fun LabeledCheckbox(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .toggleable(
                value = checked,
                onValueChange = onCheckedChange,
                role = Role.Checkbox
            )
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(label)
    }
}

@Preview(showBackground = true, heightDp = 1000)
@Composable
fun RegistrationFormScreenPreview() {
    MyFirstAppTheme {
        RegistrationFormScreen()
    }
}